import logging
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters
from handlers import start, handle_message

TELEGRAM_TOKEN = "7616182006:AAGyJMQPCY8tONIk3LOlhegI1ZT0IT3sR4A"

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO
)


def main():
    updater = Updater(token=TELEGRAM_TOKEN, use_context=True)
    dispatcher = updater.dispatcher

    dispatcher.add_handler(CommandHandler("start", start))
    dispatcher.add_handler(
        MessageHandler(Filters.text & ~Filters.command, handle_message)
    )

    print("Бот запущен! Ожидаю сообщения...")
    updater.start_polling()
    updater.idle()


if __name__ == "__main__":
    main()
