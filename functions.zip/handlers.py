import logging
from telegram import Update
from telegram.ext import CallbackContext
from summarizer import summarize_text


def start(update: Update, context: CallbackContext):
    update.message.reply_text(
        "👋 Привет! Я бот для суммаризации текста.\n\n"
        "Отправьте мне длинный текст (от 100 слов), и я сделаю его краткое содержание."
    )


def handle_message(update: Update, context: CallbackContext):
    user_text = update.message.text

    if len(user_text.split()) < 50:
        update.message.reply_text(
            "📏 Пожалуйста, пришлите более длинный текст (хотя бы 50–100 слов)."
        )
        return

    processing_message = update.message.reply_text("⏳ Обрабатываю текст...")

    try:
        result = summarize_text(user_text)
        processing_message.edit_text(f"📌 Готово! Краткое содержание:\n{result}")

    except Exception as e:
        logging.error(f"Ошибка при суммаризации: {e}")
        processing_message.edit_text(
            "⚠️ Произошла ошибка при обработке текста. Попробуйте позже."
        )
